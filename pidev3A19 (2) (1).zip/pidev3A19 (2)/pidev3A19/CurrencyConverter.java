package tools;

import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import kong.unirest.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class CurrencyConverter {
    private static final String API_KEY = "fca_live_SG4LO6z04wb8Q1bret1KIkEBm3vvzUXesXmm0Cv3";
    private static final String API_URL = "https://api.freecurrencyapi.com/v1/latest";

    private static Map<String, Double> exchangeRates = new HashMap<>();
    private static final String BASE_CURRENCY = "USD"; // L'API prend USD comme base

    public static void loadExchangeRates() {
        HttpResponse<JsonNode> response = Unirest.get(API_URL)
                .queryString("apikey", API_KEY)
                .queryString("base_currency", BASE_CURRENCY) // Utilisation de USD comme base
                .asJson();

        if (response.isSuccess()) {
            try {
                JSONObject jsonResponse = response.getBody().getObject();

                if (jsonResponse.has("data")) {
                    JSONObject data = jsonResponse.getJSONObject("data");

                    // Vérification si USD/TND est disponible (sinon, on garde un taux statique)
                    double usdToTnd = data.has("TND") ? data.getDouble("TND") : 3.0; // Valeur par défaut si absent

                    // Conversion des taux en base TND
                    Map<String, Double> rates = new HashMap<>();
                    for (String currency : data.keySet()) {
                        double rate = data.getDouble(currency);
                        rates.put(currency, rate / usdToTnd); // Ajustement par rapport au TND
                    }

                    exchangeRates = rates;
                    System.out.println("Taux de change chargés : " + rates);
                } else {
                    System.err.println("Réponse inattendue de l'API : " + jsonResponse);
                }
            } catch (Exception e) {
                System.err.println("Erreur lors du traitement de la réponse JSON : " + e.getMessage());
            }
        } else {
            // Gestion d'erreur avec affichage des détails
            System.err.println("Erreur lors du chargement des taux de change : " + response.getStatus() + " - " + response.getStatusText());
            System.err.println("Réponse brute de l'API : " + response.getBody());

            // Taux de secours en cas d'échec de l'API
            Map<String, Double> staticRates = new HashMap<>();
            staticRates.put("USD", 0.34);
            staticRates.put("EUR", 0.29);
            staticRates.put("GBP", 0.25);

            exchangeRates = staticRates;
            System.out.println("Taux de change chargés (statiques) : " + staticRates);
        }
    }

    public static double convert(double amount, String currency) {
        return exchangeRates.containsKey(currency) ? amount * exchangeRates.get(currency) : amount;
    }

    public static Map<String, Double> getAvailableCurrencies() {
        return exchangeRates;
    }
}
