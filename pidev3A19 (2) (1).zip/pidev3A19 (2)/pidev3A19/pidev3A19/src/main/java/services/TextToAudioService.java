package services;

import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class TextToAudioService {

    private static final String API_URL = "https://api-inference.huggingface.co/models/facebook/fastspeech2-en-ljspeech"; // Modèle pour le français
    private static final String API_KEY = "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"; // Remplacez par votre clé API

    /**
     * Convertit un texte en audio et sauvegarde le fichier audio.
     *
     * @param text       Le texte à convertir en audio.
     * @param outputFile Le chemin du fichier audio de sortie.
     * @param language   La langue du texte (par exemple, "fr" pour le français).
     * @return true si la conversion réussit, false sinon.
     */
    public boolean convertTextToAudio(String text, String outputFile, String language) {
        int retryCount = 3; // Nombre de tentatives
        int delay = 5000; // Délai en millisecondes entre chaque tentative

        for (int i = 0; i < retryCount; i++) {
            try {
                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(API_URL))
                        .header("Authorization", "Bearer " + API_KEY)
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString("{\"inputs\": \"" + text + "\", \"language\": \"" + language + "\"}"))
                        .build();

                HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());

                if (response.statusCode() == 200) {
                    // Vérifier que l'API retourne bien un fichier audio valide
                    if (response.body().length < 100) { // Trop petit pour être un fichier audio valide
                        System.err.println("Réponse invalide de l'API : " + new String(response.body()));
                        return false;
                    }

                    // Sauvegarde du fichier audio
                    Files.write(Path.of(outputFile), response.body(), StandardOpenOption.CREATE);
                    System.out.println("Audio généré avec succès : " + outputFile);
                    return true;
                } else if (response.statusCode() == 503) {
                    System.err.println("Tentative " + (i + 1) + " : Service indisponible. Réessai dans " + delay + " ms...");
                    Thread.sleep(delay); // Attendre avant de réessayer
                } else {
                    System.err.println("Erreur API Hugging Face : " + response.statusCode());
                    System.err.println("Réponse de l'API : " + new String(response.body()));
                    return false;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        System.err.println("Échec après " + retryCount + " tentatives.");
        return false;
    }
}