package services;

import okhttp3.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class HuggingFaceChatService {
    private static final String API_URL = "https://api-inference.huggingface.co/models/HuggingFaceH4/zephyr-7b-beta";
    private static final String API_KEY = "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"; // 🔹 Replace with your real API key!

    public static String sendMessage(String message) throws IOException {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS) // Timeout de connexion
                .readTimeout(60, TimeUnit.SECONDS)    // Timeout de lecture
                .writeTimeout(60, TimeUnit.SECONDS)   // Timeout d'écriture
                .build();
        ObjectMapper objectMapper = new ObjectMapper();

        // Build JSON request
        String json = "{ \"inputs\": \"" + message + "\" }";

        RequestBody body = RequestBody.create(json, MediaType.get("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(API_URL)
                .header("Authorization", "Bearer " + API_KEY)  // ✅ Fixed: Use "Bearer " before API Key
                .header("Content-Type", "application/json")
                .post(body)
                .build();

        Response response = client.newCall(request).execute();
        String responseBody = response.body().string();

        // Parse JSON response
        JsonNode jsonResponse = objectMapper.readTree(responseBody);

        // ✅ Check if response contains valid data
        if (jsonResponse.isArray() && jsonResponse.size() > 0 && jsonResponse.get(0).has("generated_text")) {
            return jsonResponse.get(0).get("generated_text").asText();
        } else {
            return "Error: Invalid response from API → " + responseBody;
        }
    }
}
