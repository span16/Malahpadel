package service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

public class ReservationConfirmationService {

    // Informations d'identification Twilio
    private static final String ACCOUNT_SID = "AC313fce2fdbd867eb26b947f225525fd4";
    private static final String AUTH_TOKEN = "47775aed3aeabd7882546a7ffa973ad7";
    private static final String TWILIO_PHONE_NUMBER = "+12604120323";

    // Initialisation de Twilio
    static {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

    /**
     * Envoie un SMS de confirmation de réservation.
     *
     * @param phoneNumber Le numéro de téléphone du destinataire.
     * @throws IllegalArgumentException Si le numéro de téléphone est invalide.
     * @throws RuntimeException         Si l'envoi du SMS échoue.
     */
    public static void sendReservationConfirmation(String phoneNumber) {
        // Valider le numéro de téléphone
        if (!isValidPhoneNumber(phoneNumber)) {
            throw new IllegalArgumentException("Numéro de téléphone invalide.");
        }

        // Formater le numéro de téléphone
        String formattedPhoneNumber = formatPhoneNumber(phoneNumber);

        try {
            // Envoyer le SMS de confirmation
            Message message = Message.creator(
                    new PhoneNumber(formattedPhoneNumber), // Destinataire
                    new PhoneNumber(TWILIO_PHONE_NUMBER), // Expéditeur (numéro Twilio)
                    "Votre réservation a été confirmée avec succès. Merci !" // Message
            ).create();

            System.out.println("SMS de confirmation envoyé à : " + formattedPhoneNumber);
        } catch (Exception e) {
            System.err.println("Erreur lors de l'envoi du SMS : " + e.getMessage());
            throw new RuntimeException("Échec de l'envoi du SMS. Veuillez réessayer.");
        }
    }

    /**
     * Vérifie si un numéro de téléphone est valide.
     *
     * @param phoneNumber Le numéro de téléphone à valider.
     * @return true si le numéro est valide, sinon false.
     */
    private static boolean isValidPhoneNumber(String phoneNumber) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber number = phoneUtil.parse(phoneNumber, null);
            return phoneUtil.isValidNumber(number);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Formate un numéro de téléphone au format E.164.
     *
     * @param phoneNumber Le numéro de téléphone à formater.
     * @return Le numéro de téléphone formaté.
     * @throws IllegalArgumentException Si le numéro de téléphone est invalide.
     */
    private static String formatPhoneNumber(String phoneNumber) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber number = phoneUtil.parse(phoneNumber, null);
            return phoneUtil.format(number, PhoneNumberUtil.PhoneNumberFormat.E164);
        } catch (Exception e) {
            throw new IllegalArgumentException("Numéro de téléphone invalide.");
        }
    }
}