package controllers;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import models.reservation;
import service.ReservationService;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

public class ClientAfficherReservationController {

    @FXML
    private Label lblNombrePlaces;
    @FXML
    private Label lblTypeReservation;
    @FXML
    private Label lblCodeConfirmation;
    @FXML
    private Label lblRemarque;
    @FXML
    private Label lblEvenementNom;

    private final ReservationService reservationService = new ReservationService();
    private int currentReservationId; // Pour stocker l'ID de la réservation affichée

    public void loadReservation(int reservationId) {
        this.currentReservationId = reservationId; // Sauvegarder l'ID de la réservation
        reservation res = reservationService.getReservationById(reservationId);
        if (res != null) {
            lblNombrePlaces.setText(String.valueOf(res.getNombre_places()));
            lblTypeReservation.setText(res.getType_reservation());
            lblCodeConfirmation.setText(String.valueOf(res.getCode_confirmation()));
            lblRemarque.setText(res.getRemarque());
            lblEvenementNom.setText(res.getEvenement().getNom());
        } else {
            System.out.println("Aucune réservation trouvée avec l'ID : " + reservationId);
        }
    }

    @FXML
    public void goToDashboard(javafx.event.ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ClientDashboard.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Erreur de navigation : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void annulerReservation(javafx.event.ActionEvent actionEvent) {
        // Afficher une boîte de dialogue de confirmation
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation");
        confirmationAlert.setHeaderText("Annuler la réservation");
        confirmationAlert.setContentText("Êtes-vous sûr de vouloir annuler cette réservation ?");

        Optional<ButtonType> result = confirmationAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                // Supprimer la réservation actuelle
                reservationService.supprimer(currentReservationId);
                showAlert("Succès", "La réservation a été annulée avec succès !");

                // Rediriger vers le tableau de bord après la suppression
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/ClientDashboard.fxml"));
                Parent root = loader.load();
                Stage stage = (Stage) ((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                showAlert("Erreur", "Échec de l'annulation : " + e.getMessage());
            }
        }
    }

    @FXML
    public void onImporterButtonClick(ActionEvent event) {
        try {
            // Récupérer les données de la réservation actuelle
            String nombrePlaces = lblNombrePlaces.getText();
            String typeReservation = lblTypeReservation.getText();
            String remarque = lblRemarque.getText();

            // Générer le PDF avec les données de la réservation
            genererPDF(nombrePlaces, typeReservation, remarque);

            // Afficher un message de succès
            showAlert("Succès", "Le PDF a été généré avec succès !");
        } catch (Exception e) {
            System.err.println("Erreur lors de l'exportation en PDF : " + e.getMessage());
            showAlert("Erreur", "Échec de la génération du PDF : " + e.getMessage());
        }
    }

    @FXML
    public void genererPDF(String nombrePlaces, String typeReservation, String remarque) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Enregistrer le PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers PDF", "*.pdf"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try {
                PdfWriter writer = new PdfWriter(file.getAbsolutePath());
                PdfDocument pdfDoc = new PdfDocument(writer);
                Document document = new Document(pdfDoc);

                // Ajouter le titre en gras
                Paragraph title = new Paragraph("MallahPaddel")
                        .setBold()
                        .setFontSize(18)
                        .setTextAlignment(TextAlignment.CENTER);
                document.add(title);

                // Ajouter un espace après le titre
                document.add(new Paragraph("\n"));

                // Ajouter les détails de la réservation
                document.add(new Paragraph("Confirmation de Réservation"));
                document.add(new Paragraph("Nombre de places: " + nombrePlaces));
                document.add(new Paragraph("Type de réservation: " + typeReservation));
                document.add(new Paragraph("Remarque: " + remarque));

                // Ajouter un espace avant la signature
                document.add(new Paragraph("\n\n"));

                // Ajouter la signature
                Paragraph signature = new Paragraph("Signature: __________________________")
                        .setTextAlignment(TextAlignment.RIGHT);
                document.add(signature);

                document.close();
                System.out.println("PDF généré avec succès !");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    public void goToPaiement(ActionEvent actionEvent) {
        try {
            // Charger le fichier FXML de l'interface de paiement
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ClientPaiement.fxml"));
            Parent root = loader.load();

            // Récupérer la scène actuelle à partir de l'événement
            Stage stage = (Stage) ((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();

            // Remplacer la scène actuelle par la nouvelle scène (interface de paiement)
            stage.setScene(new Scene(root));
            stage.setTitle("Paiement de la Réservation");
            stage.show();
        } catch (IOException e) {
            System.err.println("Erreur lors du chargement de la scène de paiement : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}