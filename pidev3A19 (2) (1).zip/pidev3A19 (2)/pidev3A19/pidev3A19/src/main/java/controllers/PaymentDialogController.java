package controllers;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PaymentDialogController {

    @FXML private TextField txtCardNumber;
    @FXML private TextField txtExpirationDate;
    @FXML private TextField txtCVC;
    @FXML private TextField txtCardHolder;
    @FXML private Button btnConfirmPayment;
    @FXML private ImageView visaLogo;
    @FXML private ImageView paypalLogo;
    @FXML private ImageView bitcoinLogo;
    @FXML private VBox paymentContainer;

    public PaymentDialogController() {
        // Remplace par ta clé secrète Stripe
        Stripe.apiKey = "sk_test_51PYpGGRw81LrPodfwDHPtE7KEeek0tMPB4sBxwHDuYrbhEEWE7OS6JNoRIsxIvkoZwgfF0B5lta0KC9ILn7wY3zK00ZKo98mo4";
    }
    @FXML
    private void handlePayment() {
        try {
            SessionCreateParams params = SessionCreateParams.builder()
                    .setMode(SessionCreateParams.Mode.PAYMENT)
                    .setSuccessUrl("https://example.com/success") // URL factice (non utilisée)
                    .setCancelUrl("https://example.com/cancel")   // URL factice (non utilisée)
                    .addLineItem(
                            SessionCreateParams.LineItem.builder()
                                    .setQuantity(1L)
                                    .setPriceData(
                                            SessionCreateParams.LineItem.PriceData.builder()
                                                    .setCurrency("eur")
                                                    .setUnitAmount(5000L) // Montant en centimes (50.00 EUR)
                                                    .setProductData(
                                                            SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                    .setName("Paiement Commande")
                                                                    .build()
                                                    )
                                                    .build()
                                    )
                                    .build()
                    )
                    .build();

            Session session = Session.create(params);

            // Ouvrir Stripe Checkout
            java.awt.Desktop.getDesktop().browse(new java.net.URI(session.getUrl()));

            // Attendre la fin du paiement (simulation)
            // Vous pouvez utiliser un écouteur ou une autre méthode pour détecter la fin du paiement
            showAlert("Paiement", "Paiement en cours...");

            // Rediriger vers une page locale après le paiement
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/success.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            showAlert("Erreur", "Erreur Stripe : " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.show();
    }
}
