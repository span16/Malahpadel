package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;
import javafx.event.ActionEvent;

import java.io.IOException;

public class DeconnexionController {

    @FXML
    private StackPane contentPane; // Référence au StackPane dans le FXML

    // Méthode pour gérer le clic sur le bouton "Compagne"
    @FXML
    private void handleCompagne(ActionEvent event) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource("/CompagneFrontliste.fxml"));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour gérer le clic sur le bouton "Produit"
    @FXML
    private void handleProduit(ActionEvent event) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource("/ProduitFront.fxml"));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour charger une page dans le StackPane
    private void loadPage(String fxmlPath) {
        try {
            // Charger le fichier FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ProduitFront.fxml"));
            Parent page = loader.load();

            // Effacer le contenu actuel du StackPane et ajouter la nouvelle page
            contentPane.getChildren().clear();
            contentPane.getChildren().add(page);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}