package controllers;

import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import models.Produit;
import services.ProduitService;
import services.HuggingFaceAPI;
import services.TextToAudioService;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class AjouterProduitController {

    // Champs FXML
    @FXML
    private TextField nomProduitTf;
    @FXML
    private TextField categorieTf;
    @FXML
    private TextField prixTf;
    @FXML
    private TextField stockTf;
    @FXML
    private TextArea descriptionTa;
    @FXML
    private Button afficherBtn;
    @FXML
    private ImageView descriptionImageView;
    @FXML
    private Button textToAudioButton;
    @FXML
    private ImageView imgpa; // Image statique affichée par défaut

    private String imagePath;
    private ProduitService produitService = new ProduitService();
    private TextToAudioService textToAudioService = new TextToAudioService();

    @FXML
    public void initialize() {
        ChangeListener<String> updateImageListener = new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                String productName = nomProduitTf.getText();
                String category = categorieTf.getText();
                String description = descriptionTa.getText();

                // Only generate image if we have enough information
                if (!productName.isEmpty() && !category.isEmpty() && !description.isEmpty()) {
                    generateDescriptionImage(description);
                }
            }
        };

        nomProduitTf.textProperty().addListener(updateImageListener);
        categorieTf.textProperty().addListener(updateImageListener);

        // Keep the original focus listener for the description
        descriptionTa.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue) { // Si le champ perd le focus
                String description = descriptionTa.getText();
                String productName = nomProduitTf.getText();
                String category = categorieTf.getText();

                if (!description.isEmpty() && !productName.isEmpty() && !category.isEmpty()) {
                    generateDescriptionImage(description);
                }
            }
        });
    }

    @FXML
    public void addProduit() {
        if (nomProduitTf.getText().isEmpty() || categorieTf.getText().isEmpty() ||
                prixTf.getText().isEmpty() || stockTf.getText().isEmpty() ||
                descriptionTa.getText().isEmpty() || imagePath == null) {
            showAlert("Erreur", "Tous les champs sont obligatoires !");
            return;
        }

        try {
            String nomProduit = nomProduitTf.getText();
            String categorie = categorieTf.getText();
            String description = descriptionTa.getText();
            float prix = Float.parseFloat(prixTf.getText());
            int stock = Integer.parseInt(stockTf.getText());

            Produit produit = new Produit(stock, nomProduit, categorie, imagePath, description, prix);
            produitService.ajouter(produit);

            showAlert("Succès", "Produit ajouté avec succès !");
            clearFields();
        } catch (SQLException e) {
            showAlert("Erreur SQL", "Erreur lors de l'ajout du produit : " + e.getMessage());
        } catch (NumberFormatException e) {
            showAlert("Erreur", "Veuillez entrer des valeurs valides pour le prix et le stock.");
        }
    }

    private void clearFields() {
        nomProduitTf.clear();
        categorieTf.clear();
        prixTf.clear();
        stockTf.clear();
        descriptionTa.clear();
        descriptionImageView.setImage(null);
        imagePath = null;
    }

    @FXML
    public void affichebtn(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AfficherProduit.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Liste des Produits");
            stage.show();
        } catch (IOException e) {
            System.out.println("Erreur lors du chargement de l'interface AfficherProduit.fxml : " + e.getMessage());
        }
    }

    private void generateDescriptionImage(String description) {
        HuggingFaceAPI huggingFaceAPI = new HuggingFaceAPI();

        // Get additional context from other fields
        String productName = nomProduitTf.getText();
        String category = categorieTf.getText();

        // Create a more contextualized prompt for the AI
        String enhancedPrompt = String.format("A detailed image of %s: %s. Category: %s.",
                productName,
                description,
                category);

        // Définir le chemin de stockage dans XAMPP htdocs
        String outputDir = "C:/xampp/htdocs/images/";
        File directory = new File(outputDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Générer un nom unique pour l'image
        String uniqueFileName = "product_" + productName.replaceAll("\\s+", "_").toLowerCase() + "_" +
                System.currentTimeMillis() + ".png";
        String outputFile = outputDir + uniqueFileName;

        // Générer l'image à partir de la description enrichie
        boolean success = huggingFaceAPI.generateImage(enhancedPrompt, outputFile);

        if (success) {
            // Afficher l'image générée dans descriptionImageView uniquement
            Image image = new Image(new File(outputFile).toURI().toString());
            descriptionImageView.setImage(image);
            imagePath = "http://localhost/images/" + uniqueFileName;
            showAlert("Succès", "Image générée et enregistrée sous : " + imagePath);
        } else {
            showAlert("Erreur", "La génération de l'image à partir de la description a échoué.");
        }
    }

    @FXML
    public void showDescriptionImage(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/DescriptionImage.fxml"));
            Parent root = loader.load();

            DescriptionImageController controller = loader.getController();
            controller.setImage(descriptionImageView.getImage());

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Image de la Description");
            stage.show();
        } catch (IOException e) {
            showAlert("Erreur", "Impossible de charger l'interface d'affichage de l'image.");
        }
    }

    @FXML

    private void convertTextToAudio(ActionEvent event) {
        String categorie = categorieTf.getText(); // Récupérer le texte de la catégorie

        if (!categorie.isEmpty()) {
            boolean success = textToAudioService.convertTextToAudio(categorie, "output.wav", "fr"); // "fr" pour le français

            if (success) {
                playAudio("output.wav");
            } else {
                showAlert("Erreur", "La conversion de texte en audio a échoué.");
            }
        } else {
            showAlert("Erreur", "Veuillez entrer une catégorie avant de convertir en audio.");
        }
    }
    private void playAudio(String audioFilePath) {
        try {
            File file = new File(audioFilePath);
            if (!file.exists()) {
                showAlert("Erreur", "Le fichier audio n'existe pas : " + audioFilePath);
                return;
            }

            Media media = new Media(file.toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la lecture de l'audio : " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private AnchorPane produitForm; // Référence à l'AnchorPane où vous voulez afficher le contenu

    @FXML
    private void showproduit(ActionEvent actionEvent) {
        try {
            // Charger le fichier FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/AjouterProduit.fxml"));
            Parent root = loader.load();

            // Effacer le contenu actuel de l'AnchorPane
            produitForm.getChildren().clear();

            // Ajouter le contenu chargé à l'AnchorPane
            produitForm.getChildren().add(root);

            // Optionnel : Ajuster les ancres pour que le contenu remplisse l'AnchorPane
            AnchorPane.setTopAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 0.0);
            AnchorPane.setRightAnchor(root, 0.0);

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page de gestion des produits : " + e.getMessage());
        }
    }

}
