package controllers;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class DescriptionImageController {

    @FXML
    private ImageView imageView;

    public void setImage(Image image) {
        imageView.setImage(image);
    }
}