package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import models.paiement;
import service.PaiementService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ModifierPaiementController {

    @FXML
    private TextField txtMethode_Paiement;
    @FXML private TextField txtCommission; // Nouveau champ pour la commission
    @FXML private TextField txtDescription_Paiement; // Nouveau champ pour la description du paiement
    @FXML private TextField txtDevise; // Nouveau champ pour la devise
    @FXML private Button btnSupprimer;

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void modifierPaiement(ActionEvent actionEvent) {
        try {
            String methode_Paiement = txtMethode_Paiement.getText().trim();
            float commission = Float.parseFloat(txtCommission.getText().trim());
            String description_Paiement = txtDescription_Paiement.getText().trim();
            String devise = txtDevise.getText().trim();

            // Validation des champs
            if (methode_Paiement.isEmpty() || description_Paiement.isEmpty() || devise.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Champs vides", "Veuillez remplir tous les champs.");
                return;
            }

            if (commission < 0) {
                showAlert(Alert.AlertType.ERROR, "Commission invalide", "La commission doit être un nombre positif.");
                return;
            }

            // Créer un objet paiement
            paiement p = new paiement();
            p.setMethode_Paiement(methode_Paiement);
            p.setCommission(commission);
            p.setDescription_Paiement(description_Paiement);
            p.setDevise(devise);

            // Utiliser le service pour modifier le paiement
            PaiementService paiementService = new PaiementService();
            paiementService.modifier(p);

            showAlert(Alert.AlertType.INFORMATION, "Succès", "Paiement modifié avec succès !");
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur de format", "Veuillez entrer des valeurs valides.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur SQL", "Une erreur est survenue lors de la modification : " + e.getMessage());
        }
    }

    @FXML
    private void goToSupprimer(ActionEvent event) {
        try {
            String methode_Paiement = txtMethode_Paiement.getText().trim(); // Récupérer la méthode de paiement depuis l'interface

            // Validation du champ
            if (methode_Paiement.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Champ vide", "Veuillez entrer une méthode de paiement.");
                return;
            }

            String url = "jdbc:mysql://localhost:3306/pidev";
            String username = "root";
            String password = "";

            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                String query = "DELETE FROM paiement WHERE methode_Paiement = ?"; // Utiliser methode_P pour la suppression
                try (PreparedStatement stmt = connection.prepareStatement(query)) {
                    stmt.setString(1, methode_Paiement); // Définir la valeur de methode_P

                    int affectedRows = stmt.executeUpdate();
                    if (affectedRows > 0) {
                        showAlert(Alert.AlertType.INFORMATION, "Succès", "Paiement supprimé avec succès !");
                        Stage stage = (Stage) btnSupprimer.getScene().getWindow();
                        stage.close();
                    } else {
                        showAlert(Alert.AlertType.WARNING, "Erreur", "Aucun paiement trouvé avec cette méthode de paiement.");
                    }
                }
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur SQL", "Une erreur est survenue lors de la suppression : " + e.getMessage());
        }
    }
}