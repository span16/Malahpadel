package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController {

    @FXML
    private StackPane contentPane; // Conteneur pour le contenu dynamique

    // Méthode pour charger une vue dans le StackPane
    private void loadView(String fxmlPath) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource("/AjouterProduit.fxml"));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void showSponsors(ActionEvent event) {
        loadView("/AjouterProduit.fxml"); // Charger la gestion des sponsors
    }


    @FXML
    void showEvents(ActionEvent event) {
        loadView("/events.fxml"); // Charger la gestion des événements
    }

    @FXML
    void showMatchups(ActionEvent event) {
        loadView("/matchups.fxml"); // Charger la gestion des matchs
    }

    @FXML
    void showReservations(ActionEvent event) {
        loadView("/reservations.fxml"); // Charger la gestion des réservations
    }

    @FXML
    void showUsers(ActionEvent event) {
        loadView("/users.fxml"); // Charger la gestion des utilisateurs
    }

    public void showcompagne(ActionEvent actionEvent) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource("/CompagneForm.fxml"));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(view);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void handleDeconnexion(ActionEvent event) {
        try {
            // Charger la nouvelle interface de déconnexion
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/deconnexion.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene scene = new Scene(root);

            // Obtenir la fenêtre actuelle et la modifier
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Déconnexion");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}