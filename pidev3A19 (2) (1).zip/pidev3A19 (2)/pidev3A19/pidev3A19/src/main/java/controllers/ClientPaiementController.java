package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import service.PaiementService;
import models.paiement;
import tools.CurrencyConverter;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ClientPaiementController implements Initializable {

    @FXML
    private TextField txtMethodePaiement;

    @FXML
    private TextField txtCommission;

    @FXML
    private TextField txtDescription;

    @FXML
    private TextField txtDevise;

    @FXML
    private Label lblPaiementEffectue;

    @FXML
    private ComboBox<String> conversion;

    @FXML
    private Label Prix_en_devise;

    private final PaiementService paiementService = new PaiementService();
    private paiement dernierPaiementEffectue;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            CurrencyConverter.loadExchangeRates();

            Map<String, Double> currenciesMap = CurrencyConverter.getAvailableCurrencies();
            ObservableList<String> currencies = FXCollections.observableArrayList(currenciesMap.keySet());

            if (currencies.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Aucune devise n'a été chargée. Vérifiez votre connexion Internet.");
            } else {
                conversion.setItems(currencies);
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur s'est produite lors du chargement des devises.");
            e.printStackTrace();
        }
    }

    @FXML
    private void exchange() {
        try {
            String selectedCurrency = conversion.getValue();

            if (selectedCurrency != null && !txtDevise.getText().isEmpty()) {
                double amountInTND = Double.parseDouble(txtDevise.getText());
                double convertedAmount = CurrencyConverter.convert(amountInTND, selectedCurrency);
                Prix_en_devise.setText(String.format("%.2f %s", convertedAmount, selectedCurrency));
            } else {
                Prix_en_devise.setText("Veuillez sélectionner une devise et entrer un montant.");
            }
        } catch (NumberFormatException e) {
            Prix_en_devise.setText("Montant invalide.");
        }
    }

    @FXML
    private void effectuerPaiement() {
        if (txtMethodePaiement.getText().isEmpty() || txtCommission.getText().isEmpty() ||
                txtDescription.getText().isEmpty() || txtDevise.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champs manquants", "Veuillez remplir tous les champs.");
            return;
        }

        try {
            String methodePaiement = txtMethodePaiement.getText().trim();
            float commission = Float.parseFloat(txtCommission.getText().trim());
            String description = txtDescription.getText().trim();
            String devise = txtDevise.getText().trim();

            if (commission < 0) {
                showAlert(Alert.AlertType.ERROR, "Commission invalide", "La commission ne peut pas être négative.");
                return;
            }

            dernierPaiementEffectue = new paiement(methodePaiement, commission, description, devise);
            paiementService.ajouter(dernierPaiementEffectue);

            showAlert(Alert.AlertType.INFORMATION, "Succès", "✅ Paiement effectué avec succès !");


            afficherPaiementEffectue();
            clearFields();

        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur de format", "Veuillez entrer une valeur numérique valide pour la commission.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur SQL", "❌ Une erreur SQL s'est produite : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void afficherPaiementEffectue() {
        if (dernierPaiementEffectue != null) {
            String detailsPaiement = "Dernier paiement effectué :\n" +
                    "Méthode : " + dernierPaiementEffectue.getMethode_Paiement() + "\n" +
                    "Commission : " + dernierPaiementEffectue.getCommission() + "\n" +
                    "Description : " + dernierPaiementEffectue.getDescription_Paiement() + "\n" +
                    "Devise : " + dernierPaiementEffectue.getDevise();

            lblPaiementEffectue.setText(detailsPaiement);
        } else {
            showAlert(Alert.AlertType.WARNING, "Aucun paiement", "Aucun paiement n'a été effectué pour le moment.");
        }
    }

    @FXML
    private void openStripePayment() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/payment_dialog.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Paiement Stripe");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.out.println("Erreur lors de l'ouverture du paiement Stripe : " + e.getMessage());
        }
    }
    @FXML
    private void afficherDernierPaiement() {
        if (dernierPaiementEffectue != null) {
            String detailsPaiement = "Dernier paiement effectué :\n" +
                    "Méthode : " + dernierPaiementEffectue.getMethode_Paiement() + "\n" +
                    "Commission : " + dernierPaiementEffectue.getCommission() + "\n" +
                    "Description : " + dernierPaiementEffectue.getDescription_Paiement() + "\n" +
                    "Devise : " + dernierPaiementEffectue.getDevise();

            try {
                System.out.println("Détails à afficher: " + detailsPaiement);  // Log des détails

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/DetailsPaiement.fxml"));
                Parent root = loader.load();

                // Récupérer le contrôleur de la fenêtre de détails
                DetailsPaiementController detailsController = loader.getController();
                detailsController.setDetails(detailsPaiement);

                Stage stage = new Stage();
                stage.setTitle("Détails du Paiement");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'affichage des détails du paiement.");
                e.printStackTrace();
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Aucun paiement", "Aucun paiement n'a été effectué pour le moment.");
        }
    }



    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        txtMethodePaiement.clear();
        txtCommission.clear();
        txtDescription.clear();
        txtDevise.clear();
    }


}