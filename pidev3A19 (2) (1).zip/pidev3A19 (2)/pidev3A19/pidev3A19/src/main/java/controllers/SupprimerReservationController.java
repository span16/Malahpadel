package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import service.ReservationService;
import models.Evenement;


import java.io.IOException;
import java.sql.SQLException;

public class SupprimerReservationController {

    @FXML
    private TextField txtIdR;  // ID de la réservation à supprimer

    @FXML
    private TextField txtNombrePlaces; // Nombre de places (si nécessaire pour affichage)

    @FXML
    private TextField txtTypeReservation; // Type de réservation (si nécessaire pour affichage)

    @FXML
    private TextField txtCodeConfirmation; // Code de confirmation (si nécessaire pour affichage)

    @FXML
    private TextField txtRemarque; // Remarque (si nécessaire pour affichage)


    @FXML
    void deleteReservation(ActionEvent event) {
        int id_R = Integer.parseInt(txtIdR.getText());  // Récupération de l'ID de la réservation

        ReservationService sr = new ReservationService();

        try {
            // Vérification si la réservation existe avec l'ID_R
            if (sr.reservationExists(id_R)) {
                // Suppression de la réservation par ID_R
                int rowsDeleted = sr.supprimer(id_R);

                if (rowsDeleted > 0) {
                    System.out.println("✅ Réservation avec ID_R " + id_R + " supprimée !");
                } else {
                    System.out.println("⚠️ Échec de la suppression de la réservation !");
                }
            } else {
                System.out.println("⚠️ Aucune réservation trouvée avec l'ID_R : " + id_R);
            }
        } catch (SQLException e) {
            System.out.println("Erreur SQL : " + e.getMessage());
        }

        // Rediriger vers la page d'affichage des réservations
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AfficherReservation.fxml"));
            Parent root = loader.load();

            AfficherReservationController ar = loader.getController();
            ar.loadReservations();  // Charger toutes les réservations
            txtIdR.getScene().setRoot(root);
        } catch (IOException e) {
            System.out.println("Erreur lors de la redirection vers la page d'affichage des réservations : " + e.getMessage());
        }
    }

    public void goToAjouter(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterReservation.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) txtIdR.getScene().getWindow();
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erreur de navigation vers AjouterReservation : " + e.getMessage());
        }
    }
}
