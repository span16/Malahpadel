package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.reservation;
import models.Evenement;
import service.ReservationService;
import service.EvenementService;
import service.ReservationConfirmationService;

import java.io.IOException;
import java.sql.SQLException;

public class ClientAjouterReservationController {

    @FXML
    private TextField txtNombrePlaces;
    @FXML
    private TextField txtTypeReservation;
    @FXML
    private TextField txtCodeConfirmation;
    @FXML
    private TextField txtRemarque;
    @FXML
    private ComboBox<String> comboEvenementNom;
    @FXML
    private TextField txtPhoneNumber;

    private final EvenementService evenementService = new EvenementService();

    @FXML
    public void initialize() {
        try {
            comboEvenementNom.getItems().addAll(evenementService.getAllEvenementNames());
        } catch (SQLException e) {
            System.err.println("Erreur lors du chargement des événements : " + e.getMessage());
        }
    }

    @FXML
    void addReservation(ActionEvent event) {
        // Vérification des champs
        if (txtNombrePlaces.getText().isEmpty() || txtTypeReservation.getText().isEmpty() ||
                txtCodeConfirmation.getText().isEmpty() || comboEvenementNom.getValue() == null) {
            showAlert("Champs manquants", "Veuillez remplir tous les champs.");
            return;
        }

        int nombrePlaces, codeConfirmation;
        String evenementNom = comboEvenementNom.getValue();

        try {
            nombrePlaces = Integer.parseInt(txtNombrePlaces.getText());
            codeConfirmation = Integer.parseInt(txtCodeConfirmation.getText());

            if (nombrePlaces <= 0 || codeConfirmation <= 0) {
                showAlert("Erreur", "Les valeurs doivent être des nombres positifs.");
                return;
            }
        } catch (NumberFormatException e) {
            showAlert("Erreur de Saisie", "Les identifiants et autres champs numériques doivent être valides.");
            return;
        }

        String typeReservation = txtTypeReservation.getText().trim();
        String remarque = txtRemarque.getText().trim();

        // Récupérer l'événement par son nom
        Evenement ev;
        try {
            ev = evenementService.getEvenementByNom(evenementNom);
            if (ev == null) {
                showAlert("Erreur", "L'événement spécifié n'existe pas.");
                return;
            }
        } catch (SQLException e) {
            showAlert("Erreur de Base de Données", "Échec de la récupération de l'événement : " + e.getMessage());
            return;
        }

        // Créer la réservation
        reservation r = new reservation(nombrePlaces, typeReservation, codeConfirmation, remarque, ev);
        ReservationService sr = new ReservationService();

        try {
            sr.ajouter(r);
            showAlert("Succès", "Réservation ajoutée avec succès !");

            // Rediriger vers l'affichage de la réservation
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ClientAfficherReservation.fxml"));
            Parent root = loader.load();

            ClientAfficherReservationController ar = loader.getController();
            ar.loadReservation(r.getId_R()); // Charger les détails de la réservation

            txtTypeReservation.getScene().setRoot(root);
        } catch (SQLException | IOException e) {
            showAlert("Erreur", "Échec de l'ajout ou de la navigation : " + e.getMessage());
        }
    }
    @FXML
    void sendSMSConfirmation(ActionEvent event) {
        // Récupérer le numéro de téléphone depuis le champ de texte
        String phoneNumber = txtPhoneNumber.getText().trim();

        if (phoneNumber.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer un numéro de téléphone.");
            return;
        }

        try {
            // Envoyer le SMS de confirmation
            ReservationConfirmationService.sendReservationConfirmation(phoneNumber);
            showAlert("Succès", "SMS de confirmation envoyé avec succès !");
        } catch (Exception e) {
            showAlert("Erreur", "Échec de l'envoi du SMS : " + e.getMessage());
        }
    }
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}