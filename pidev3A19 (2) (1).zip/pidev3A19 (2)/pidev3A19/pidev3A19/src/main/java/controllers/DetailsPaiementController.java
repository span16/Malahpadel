package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class DetailsPaiementController {

    @FXML
    private Label lblDetails;

    public void setDetails(String details) {
        try {
            System.out.println("Setting details: " + details);  // Log pour vérifier la valeur passée
            lblDetails.setText(details);
        } catch (Exception e) {
            e.printStackTrace();  // Afficher la pile d'exécution pour comprendre l'erreur
        }
    }

}